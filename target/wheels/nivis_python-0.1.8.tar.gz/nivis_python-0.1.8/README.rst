|ruff|

Nivis
=======

    ❄ Lightweight and easy-to-use multi-paradigm interactive scripting language.

Welcome to nivis community!


.. |ruff| image:: https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json
    :target: https://github.com/astral-sh/ruff
    :alt: Ruff