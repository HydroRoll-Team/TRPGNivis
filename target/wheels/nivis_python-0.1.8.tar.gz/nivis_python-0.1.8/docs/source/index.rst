.. hide-toc: true

Nivis - ❄
=========

.. include:: ../../README.rst
   :start-after: .. index-start
   :end-before: .. index-end


.. toctree::
    :hidden:

    Quick start <pages/quick-start.rst>


.. toctree::
    :caption: Development
    :hidden:

    CONTRIBUTING <pages/development/contributing.rst>
    CHANGELOG <changelog.rst>
    COPYING <COPYING.rst>